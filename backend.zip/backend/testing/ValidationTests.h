#pragma once

void runAllValidationTests();
