#pragma once

void runAllManualTests();
