#pragma once

void runAllValidationTests();