#pragma once

void runAllManualTests();